import os
import json
import logging
import pytz
from datetime import datetime
import pandas as pd
import azure.functions as func
from azure.storage.blob import BlobServiceClient

# Initialize Function App
app = func.FunctionApp()

# Runs at second 0 of every minute, Monday through Friday
@app.timer_trigger(schedule="0 * * * * 1-5", arg_name="mytimer", run_on_startup=False, use_monitor=False)
def market_data_fetcher(mytimer: func.TimerRequest) -> None:
    # ---------------------------------------------------------
    # 1. Check Test Mode & Market Hours
    # ---------------------------------------------------------
    test_mode = os.getenv("TEST_MODE", "false").strip().lower() == "true"
    
    ist_timezone = pytz.timezone('Asia/Kolkata')
    current_ist_time = datetime.now(ist_timezone)
    
    market_open = current_ist_time.replace(hour=9, minute=15, second=0, microsecond=0)
    market_close = current_ist_time.replace(hour=15, minute=30, second=0, microsecond=0)
    
    is_market_open = market_open <= current_ist_time <= market_close

    # Exit if market is closed and TEST_MODE is not enabled
    if not is_market_open and not test_mode:
        logging.info(
            f"Market is closed in IST ({current_ist_time.strftime('%H:%M:%S')}). "
            f"TEST_MODE is disabled. Skipping execution."
        )
        return

    logging.info(
        f"=== Starting Execution at {current_ist_time.strftime('%Y-%m-%d %H:%M:%S')} IST "
        f"(Test Mode: {test_mode}) ==="
    )

    # ---------------------------------------------------------
    # 2. Verify Environment Variables & Broker Key
    # ---------------------------------------------------------
    broker_api_key = os.getenv("BROKER_API_KEY", "KeyNotFound")
    
    if broker_api_key == "KeyNotFound":
        logging.warning("[WARN] BROKER_API_KEY environment variable is NOT set.")
    else:
        # Mask the key for security in logs (shows first 3 and last 3 chars)
        masked_key = (
            f"{broker_api_key[:3]}...{broker_api_key[-3:]}"
            if len(broker_api_key) > 6
            else "***"
        )
        logging.info(f"[OK] Successfully read BROKER_API_KEY: {masked_key}")

    # ---------------------------------------------------------
    # 3. Generate Dummy Market Data
    # ---------------------------------------------------------
    live_data = [
        {"symbol": "NIFTY", "strike": 22500, "type": "CE", "price": 120.50, "volume": 4500},
        {"symbol": "NIFTY", "strike": 22500, "type": "PE", "price": 110.25, "volume": 3800},
        {"symbol": "BANKNIFTY", "strike": 48000, "type": "CE", "price": 310.75, "volume": 2100}
    ]
    logging.info(f"[OK] Generated {len(live_data)} records of market data.")

    # ---------------------------------------------------------
    # 4. Upload to Azure Blob Storage
    # ---------------------------------------------------------
    storage_connection = os.getenv("MARKET_STORAGE_CONNECTION")
    if not storage_connection:
        logging.error("[ERROR] MARKET_STORAGE_CONNECTION is not set in Environment Variables!")
        return

    try:
        blob_service_client = BlobServiceClient.from_connection_string(storage_connection)
        
        folder_date = current_ist_time.strftime('%Y-%m-%d')
        file_time = current_ist_time.strftime('%H%M%S')

        # --- A. Save as JSON ---
        json_blob_name = f"{folder_date}/json_data/tick_{file_time}.json"
        json_client = blob_service_client.get_blob_client(container="market-data", blob=json_blob_name)
        json_client.upload_blob(json.dumps(live_data, indent=2), overwrite=True)
        logging.info(f"[OK] Successfully uploaded JSON: {json_blob_name}")

        # --- B. Save as Parquet ---
        df = pd.DataFrame(live_data)
        parquet_bytes = df.to_parquet(engine='pyarrow')
        parquet_blob_name = f"{folder_date}/parquet_data/tick_{file_time}.parquet"
        parquet_client = blob_service_client.get_blob_client(container="market-data", blob=parquet_blob_name)
        parquet_client.upload_blob(parquet_bytes, overwrite=True)
        logging.info(f"[OK] Successfully uploaded Parquet: {parquet_blob_name}")

    except Exception as e:
        logging.error(f"[ERROR] Failed during blob storage upload: {e}")

    logging.info("=== Execution Completed Successfully ===")